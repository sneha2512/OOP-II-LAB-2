
abstract class Vehicle {
    /**
     * 
     * Attribute
     */
    int speed = 0;
    /**
     * 
     * Attribute
     */
    int Capacity = 0;
    
    /**
     * 
     * Abstract Methods
     */
    abstract void accelerate();//Accleration of the vehicle
    abstract void stop();//Stopping the vehicle
    abstract void gas();//Checking the fuel tank of the vehicle
    
}
