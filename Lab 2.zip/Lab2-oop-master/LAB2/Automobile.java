
interface Automobile {
    /**
     * 
     * @param newIncrement
     */
    void accelerate(int moreSpeed);
    /**
     * 
     * @param newDecrement
     */
    void stop(int lessSpeed);
    /**
     * 
     * @param newFuelCapacity
     */
    void gas(int Capacity);
}

