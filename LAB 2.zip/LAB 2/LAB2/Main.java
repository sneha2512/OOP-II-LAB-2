
public class Main {
    public static void main(String[] args) {
        /**
         * 
         * Creating a new instance of the Sedan Class Object
         */
        Sedan Ash = new Sedan();
        Ash.accelerate();
        
	    Ash.accelerate(9);
        
        Ash.accelerate(4);
    }
}
