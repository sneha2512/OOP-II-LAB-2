
public class Bus extends Vehicle {
    void accelerate(){}
    
    void stop(){}

    void gas(){}
}
